package vce.ac.in;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class ViewComputer extends Panel 
{
	Button updateCompButton,removeCompButton;
	List compList;
	TextField cidText, mnfText, macText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewComputer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","it18737065","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void loadComputers() 
	{	   
		try 
		{
			compList.removeAll();
		  rs = statement.executeQuery("SELECT cid FROM COMPUTERS");
		  while (rs.next()) 
		  {
			  compList.add(rs.getString("cid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		compList = new List(10);
		loadComputers();
		add(compList);
		
		//When a list item is selected populate the text fields
		compList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM COMPUTERS where cid ="+compList.getSelectedItem());
					rs.next();
					cidText.setText(rs.getString("cid"));
					mnfText.setText(rs.getString("manufacturer"));
					macText.setText(rs.getString("mac_address"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateCompButton = new Button("Modify");
		updateCompButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE COMPUTERS SET MANUFACTURER ='"+mnfText.getText()+"',"+ " MAC_ADDRESS='"+macText.getText()+"'"+" WHERE cid ="+compList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					//compList.removeAll();
					loadComputers();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		//Handle Delete Sailor Button
				removeCompButton = new Button("Delete");
				removeCompButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e) 
					{
						try 
						{
							Statement statement = connection.createStatement();
							int i = statement.executeUpdate("DELETE FROM COMPUTERS WHERE cid = "+ compList.getSelectedItem());
							errorText.append("\nDeleted " + i + " rows successfully");
							cidText.setText(null);
							mnfText.setText(null);
							macText.setText(null);
							loadComputers();
						} 
						catch (SQLException insertException) 
						{
							displaySQLErrors(insertException);
						}
					}
				});
		
		cidText = new TextField(15);
		cidText.setEditable(false);
		mnfText = new TextField(15);
		macText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("System no.:"));
		first.add(cidText);
		first.add(new Label("MANUFACTURER:"));
		first.add(mnfText);
		first.add(new Label("MAC_ADDRESS:"));
		first.add(macText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateCompButton);
		second.add(removeCompButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
		
		errorText.setBackground(Color.BLACK);
		errorText.setForeground(Color.WHITE);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		ViewComputer vc = new ViewComputer();
		vc.buildGUI();
	}
}
