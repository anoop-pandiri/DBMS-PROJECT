package vce.ac.in;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class ViewLab extends Panel 
{
	Button updateLabButton,removeLabButton;
	List labList;
	TextField lnText, flText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewLab() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","it18737065","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void loadLabs() 
	{	   
		try 
		{
		  labList.removeAll();
		  rs = statement.executeQuery("SELECT labname FROM LABS");
		  while (rs.next()) 
		  {
			  labList.add(rs.getString("labname"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		labList = new List(10);
		loadLabs();
		add(labList);
		
		//When a list item is selected populate the text fields
		labList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM LABS where labname ="+"'"+labList.getSelectedItem()+"'");
					rs.next();
					lnText.setText(rs.getString("labname"));
					flText.setText(rs.getString("floor"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateLabButton = new Button("Modify");
		updateLabButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE LABS SET floor ="+flText.getText()+" WHERE labname ='"+labList.getSelectedItem()+"'");
					errorText.append("\nUpdated " + i + " rows successfully");
					//labList.removeAll();
					loadLabs();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		
		//Handle Delete Sailor Button
		removeLabButton = new Button("Delete");
		removeLabButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
							Statement statement = connection.createStatement();
							int i = statement.executeUpdate("DELETE FROM labs WHERE labname = '"+ labList.getSelectedItem()+"'");
							errorText.append("\nDeleted " + i + " rows successfully");
							lnText.setText(null);
							flText.setText(null);
							loadLabs();
				} 
				catch (SQLException insertException) 
				{
							displaySQLErrors(insertException);
				}
			}
		});
		
		lnText = new TextField(15);
		lnText.setEditable(false);
		flText = new TextField(15);
		flText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Lab Name:"));
		first.add(lnText);
		first.add(new Label("Floor:"));
		first.add(flText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateLabButton);
		second.add(removeLabButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
		
		errorText.setBackground(Color.BLACK);
		errorText.setForeground(Color.WHITE);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args)
	{
		ViewLab vl = new ViewLab();
	
		vl.buildGUI();
	}
}