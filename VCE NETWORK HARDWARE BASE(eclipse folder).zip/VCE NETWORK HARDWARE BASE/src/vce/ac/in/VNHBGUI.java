package vce.ac.in;
import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;

class VNHBGUI extends Frame implements ActionListener
{ 
	  String msg = ""; 
	  Label ll;
	  CardLayout cardLO;
	  
	  //Create Panels for each of the menu items, welcome screen panel and home screen panel with CardLayout
	  AddBlock adb;
	  AddLab adl;
	  AddComputer adc;
	  AddLan adlan;
	  AddWan adwan;
	  
	  ViewBlock vb;
	  ViewLab vl;
	  ViewComputer vc;
	  ViewLan vlan;
	  ViewWan vwan;
	  
	  ManageLabs ml;
	  ManageComputers mc;
	  ManageLan mlan;
	  ManageWan mwan;
	
	  Panel home,welcome;
	  
	  VNHBGUI()
	  { 
			cardLO = new CardLayout();
			
			//Create an empty home panel and set its layout to card layout 
			home = new Panel(); 
			home.setLayout(cardLO);  

			
			ll = new Label();
			ll.setAlignment(Label.CENTER);  
			ll.setText("VCE Network Hardware Base");
			
			//Create welcome panel and add the label to it
			welcome = new Panel();
			welcome.add(ll);
			
			//create panels for each of our menu items and build them with respective components
			adb = new AddBlock(); 		adb.buildGUI();
			adl = new AddLab();   		adl.buildGUI();
			adc = new AddComputer();	adc.buildGUI();
			adlan=new AddLan();    		adlan.buildGUI();
			adwan=new AddWan();    		adwan.buildGUI();
			
			
			vb = new ViewBlock(); 	vb.buildGUI();
			vl = new ViewLab();   	vl.buildGUI();
			vc = new ViewComputer(); vc.buildGUI();
			vlan=new ViewLan(); 		vlan.buildGUI();
			vwan=new ViewWan(); 		vwan.buildGUI();
			
			ml = new ManageLabs(); ml.buildGUI();
			mc = new ManageComputers(); mc.buildGUI();
			mlan = new ManageLan();   mlan.buildGUI();
			mwan = new ManageWan();   mwan.buildGUI();
			
			
			//add all the panels to the home panel which has a cardlayout
			home.add(welcome, "Welcome"); 
			home.add(adb, "AddBlock");
			home.add(adl,"AddLab");
			home.add(adc,"AddComputer");
			home.add(adlan,"AddLan");
			home.add(adwan,"AddWan");
			
			home.add(vb,"ViewBlock");
			home.add(vl,"ViewLab");
			home.add(vc,"ViewComputer");
			home.add(vlan,"ViewLan");
			home.add(vwan,"ViewWan");
			
			home.add(ml,"ManageLabs");
			home.add(mc,"ManageComputers");
			home.add(mlan,"ManageLan");
			home.add(mwan,"ManageWan");
		 
			// add home panel to main frame  
			add(home); 
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			
			Menu block = new Menu("Block"); 
			MenuItem item1, item2; 
			block.add(item1 = new MenuItem("Add Block"));
			block.add(item2 = new MenuItem("View Blocks")); 
			mbar.add(block);  
		 
			Menu lab = new Menu("Labs"); 
			MenuItem item3, item4; 
			lab.add(item3 = new MenuItem("Add Lab")); 
			lab.add(item4 = new MenuItem("View Labs"));
			mbar.add(lab); 
			
			Menu computer = new Menu("Computers");
			MenuItem item5, item6; 
			computer.add(item5 = new MenuItem("Add Computer")); 
			computer.add(item6 = new MenuItem("View Computers")); 
			mbar.add(computer);
			
			Menu lan = new Menu("LAN"); 
			MenuItem item7, item8; 
			lan.add(item7 = new MenuItem("Add LAN Device"));   
			lan.add(item8 = new MenuItem("View LAN Devices"));  
			mbar.add(lan);
			
			Menu wan = new Menu("WAN"); 
			MenuItem item9, item10; 
			wan.add(item9 = new MenuItem("Add WAN Device")); 
			wan.add(item10 = new MenuItem("View WAN Devices")); 
			mbar.add(wan);
			
			Menu manage = new Menu("Manage");
			MenuItem item11,item12,item13,item14,item15;
			manage.add(item11 = new MenuItem("Labs"));
			manage.add(item12 = new MenuItem("Computers"));
			manage.add(item13 = new MenuItem("LAN"));
			manage.add(item14 = new MenuItem("WAN"));
			manage.add(item15 = new MenuItem("Internet"));
			mbar.add(manage);
			
			Menu help = new Menu("Help");
			MenuItem About , Credits ;
			help.add(About = new MenuItem("About"));
			help.add(Credits = new MenuItem("Credits"));
			mbar.add(help);
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this);
			item3.addActionListener(this);
			item4.addActionListener(this);
			item5.addActionListener(this);
			item6.addActionListener(this);
			item7.addActionListener(this);
			item8.addActionListener(this); 
			item9.addActionListener(this); 
			item10.addActionListener(this);
			item11.addActionListener(this);
			item12.addActionListener(this);
			item13.addActionListener(this);
			item14.addActionListener(this);
			item15.addActionListener(this);
			About.addActionListener(this);
			Credits.addActionListener(this);
						
					
			 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{	
						System.exit(0);	
				} 
			});
			
			//Frame properties
			setTitle("VCE Network Hardware Base"); 
			Color clr = new Color(230,230,230);
			setBackground(clr); 
			setFont(new Font("SansSerif", Font.BOLD, 14));
			//setForeground(Color.WHITE);
			setSize(500, 600); 
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 
		  String arg = ae.getActionCommand(); 
		  
		 
		  if(arg.equals("Add Block"))
		  {
			cardLO.show(home, "AddBlock"); 			
          }			
		 
		 else if(arg.equals("View Blocks")) 
		 {
			cardLO.show(home, "ViewBlock");
			vb.loadBlocks();
		 }
		 
		 else if(arg.equals("Add Lab")) 
		 {
			cardLO.show(home, "AddLab");
		 }
		  
		 else if(arg.equals("View Labs"))
		 {
			cardLO.show(home, "ViewLab");	
			vl.loadLabs();
		 }
		  
		 else if(arg.equals("Add Computer")) 
		 {
			cardLO.show(home, "AddComputer"); 				
		 }
		  
		 else if(arg.equals("View Computers")) 
		 {
			cardLO.show(home, "ViewComputer");
			vc.loadComputers();
		 }
		  
		 else if(arg.equals("Add LAN Device")) 
		 {
			cardLO.show(home, "AddLan"); 			
		 }
		  
		 else if(arg.equals("View LAN Devices")) 
		 {
			cardLO.show(home, "ViewLan"); 
			vlan.loadLAN();
		 }
		  
		 else if(arg.equals("Add WAN Device")) 
		 {
			cardLO.show(home, "AddWan"); 			
		 }
		  
		 else if(arg.equals("View WAN Devices")) 
		 {
			cardLO.show(home, "ViewWan");
			vwan.loadWAN();
		 }
		 else if(arg.equals("Labs"))
		 {
			cardLO.show(home, "ManageLabs"); 			
         }
		 else if(arg.equals("Computers"))
		 {
			cardLO.show(home, "ManageComputers"); 			
         }	
		 else if(arg.equals("LAN"))
		 {
			cardLO.show(home, "ManageLan"); 			
         }	
		 else if(arg.equals("WAN"))
		 {
			cardLO.show(home, "ManageWan"); 			
         }	
		 else if(arg.equals("Internet"))
		 {
			cardLO.show(home, "Internet"); 			
         }	
		  

		 else if(arg.contentEquals("About"))
		 {
			 JOptionPane.showMessageDialog(this, "                VCE NETWORK HARDWARE BASE\n              \n              \n  �VCE Network Hardware Base . All Rights Reserved", "About",JOptionPane.PLAIN_MESSAGE);
			 setBackground(Color.DARK_GRAY);
		 }
		 else if(arg.equals("Credits"))
		 {
			 JOptionPane.showMessageDialog(this, "               Name : Anoop\n              Roll no : 1602-18-737-065\n              Section : IT-B\n  �VCE Network Hardware Base . All Rights Reserved", "Credits",JOptionPane.PLAIN_MESSAGE);
			 
		 }
	  }
	  public static void main(String ... args)
	  {
			new VNHBGUI();
	  }
}