package vce.ac.in;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class ViewWan extends Panel 
{
	Button updateWanButton,removeDeviceButton;
	List deviceList;
	TextField didText, dnameText, dspeedText,ipText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ViewWan() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","it18737065","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void loadWAN() 
	{	   
		try 
		{
		  deviceList.removeAll();
		  rs = statement.executeQuery("SELECT W_DEVICE_ID FROM WAN");
		  while (rs.next()) 
		  {
			  deviceList.add(rs.getString("W_DEVICE_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		deviceList = new List(10);
		loadWAN();
		add(deviceList);
		
		//When a list item is selected populate the text fields
		deviceList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM WAN where W_DEVICE_ID ="+deviceList.getSelectedItem());
					rs.next();
					didText.setText(rs.getString("W_DEVICE_ID"));
					dnameText.setText(rs.getString("W_DEVICE_NAME"));
					dspeedText.setText(rs.getString("W_SPEED"));
					ipText.setText(rs.getString("W_IP_ADDRESS"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateWanButton = new Button("Modify");
		updateWanButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE WAN SET W_DEVICE_NAME ='"+dnameText.getText()+"',"+ " W_SPEED='"+dspeedText.getText()+"', W_IP_ADDRESS ='"+ipText.getText()+"'  WHERE W_DEVICE_ID ="+deviceList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					//deviceList.removeAll();
					loadWAN();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		
		//Handle Delete Sailor Button
		removeDeviceButton = new Button("Delete");
		removeDeviceButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM WAN WHERE W_DEVICE_ID = "+ deviceList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					didText.setText(null);
					dnameText.setText(null);
					dspeedText.setText(null);
					ipText.setText(null);
					deviceList.removeAll();
					loadWAN();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		didText = new TextField(15);
		didText.setEditable(false);
		dnameText = new TextField(15);
		dspeedText = new TextField(15);
		ipText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("DEVICE ID:"));
		first.add(didText);
		first.add(new Label("DEVICE NAME:"));
		first.add(dnameText);
		first.add(new Label("SPEED:"));
		first.add(dspeedText);
		first.add(new Label("IP_ADDRESS:"));
		first.add(ipText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateWanButton);
		second.add(removeDeviceButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
		
		errorText.setBackground(Color.BLACK);
		errorText.setForeground(Color.WHITE);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	
	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args)
	{
		ViewWan vwan = new ViewWan();

		vwan.buildGUI();
	}
}