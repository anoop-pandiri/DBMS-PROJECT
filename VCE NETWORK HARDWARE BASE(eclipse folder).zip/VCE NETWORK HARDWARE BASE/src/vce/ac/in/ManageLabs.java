package vce.ac.in;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class ManageLabs extends Panel 
{
	Button updateLabButton;
	List labList,bNameList;
	TextField lnText, flText,bNameText, branchText, hodText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public ManageLabs() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","it18737065","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void loadLabs() 
	{	   
		try 
		{
		  labList.removeAll();
		  rs = statement.executeQuery("SELECT labname FROM LABS");
		  while (rs.next()) 
		  {
			  labList.add(rs.getString("labname"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void loadBlocks() 
	{	   
		try 
		{
		  bNameList.removeAll();
		  rs = statement.executeQuery("SELECT bname FROM BLOCK");
		  while (rs.next()) 
		  {
			  bNameList.add(rs.getString("bname"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		labList = new List(10);
		loadLabs();
		add(labList);
		bNameList = new List(10);
		loadBlocks();
		add(bNameList);
		
		
		//When a list item is selected populate the text fields
		labList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM LABS where labname ="+"'"+labList.getSelectedItem()+"'");
					rs.next();
					lnText.setText(rs.getString("labname"));
					flText.setText(rs.getString("floor"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	
		
		
		//When a list item is selected populate the text fields
				bNameList.addItemListener(new ItemListener()
				{
					public void itemStateChanged(ItemEvent e) 
					{
						try 
						{
							rs = statement.executeQuery("SELECT * FROM BLOCK where bname ="+"'"+bNameList.getSelectedItem()+"'");
							rs.next();
							bNameText.setText(rs.getString("bname"));
							branchText.setText(rs.getString("branch"));
							hodText.setText(rs.getString("hod"));
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}
					}
				});	
		
	    
		//Handle Update Sailor Button
		updateLabButton = new Button("Submit");
		updateLabButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("INSERT INTO HAS VALUES ("+"'"+ bNameText.getText()+"', '"+lnText.getText()+"')");
					errorText.append("\nUpdated " + i + " rows successfully");
					//labList.removeAll();
					loadLabs();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		
		
		
		lnText = new TextField(15);
		lnText.setEditable(false);
		flText = new TextField(15);
		flText = new TextField(15);
		
		
		bNameText = new TextField(15);
		bNameText.setEditable(false);
		branchText = new TextField(15);
		hodText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Lab Name:"));
		first.add(lnText);
		first.add(new Label("Floor:"));
		first.add(flText);
		
		//first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Block Name:"));
		first.add(bNameText);
		first.add(new Label("BRANCH:"));
		first.add(branchText);
		first.add(new Label("HOD:"));
		first.add(hodText);
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateLabButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
		
		errorText.setBackground(Color.BLACK);
		errorText.setForeground(Color.WHITE);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args)
	{
		ManageLabs ml = new ManageLabs();
	
		ml.buildGUI();
	}
}