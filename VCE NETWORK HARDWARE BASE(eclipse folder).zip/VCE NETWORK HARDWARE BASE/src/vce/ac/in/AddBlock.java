package vce.ac.in;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class AddBlock extends Panel 
{
	Button AddBlockButton;
	TextField bnameText, branchText, hodText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public AddBlock() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB()
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","it18737065","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		AddBlockButton = new Button("Submit");
		AddBlockButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO BLOCK (BNAME,BRANCH, HOD) VALUES ('RAMANUJAN','IT','RamMohanRao')";				  
				  String query= "INSERT INTO BLOCK VALUES(" +"'"+ bnameText.getText()+"', " + "'" + branchText.getText() + "'," +"'"+ hodText.getText() +"')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		bnameText = new TextField(15);
		branchText = new TextField(15);
		hodText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Block Name:"));
		first.add(bnameText);
		first.add(new Label("Branch:"));
		first.add(branchText);
		first.add(new Label("HOD:"));
		first.add(hodText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(AddBlockButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setVisible(true);
		
		errorText.setBackground(Color.BLACK);
		errorText.setForeground(Color.WHITE);
	}

	private void displaySQLErrors(SQLException e)
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args)
	{
		AddBlock adb = new AddBlock();	
		adb.buildGUI();
	}
}