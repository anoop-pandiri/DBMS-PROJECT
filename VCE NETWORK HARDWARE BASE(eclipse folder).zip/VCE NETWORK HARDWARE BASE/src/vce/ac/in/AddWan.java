package vce.ac.in;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class AddWan extends Panel 
{
	Button AddWanButton;
	TextField W_DEVICE_IDText, W_DEVICE_NAMEText, W_SPEEDText,W_IP_ADDRESSText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public AddWan() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB()
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","it18737065","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		AddWanButton = new Button("Submit");
		AddWanButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO WAN (SID,SNAME, RATING, AGE) VALUES (2,'Divya',7,20)";				  
				  String query= "INSERT INTO WAN VALUES(" + W_DEVICE_IDText.getText()+", " + "'" + W_DEVICE_NAMEText.getText() + "'," +"'"+ W_SPEEDText.getText()+"',"+"'"+W_IP_ADDRESSText.getText() +"')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		W_DEVICE_IDText = new TextField(15);
		W_DEVICE_NAMEText = new TextField(15);
		W_SPEEDText = new TextField(15);
		W_IP_ADDRESSText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Device ID:"));
		first.add(W_DEVICE_IDText);
		first.add(new Label("Device Name:"));
		first.add(W_DEVICE_NAMEText);
		first.add(new Label("Speed:"));
		first.add(W_SPEEDText);
		first.add(new Label("IP Address:"));
		first.add(W_IP_ADDRESSText);
		
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(AddWanButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setVisible(true);
		
		errorText.setBackground(Color.BLACK);
		errorText.setForeground(Color.WHITE);
	}

	private void displaySQLErrors(SQLException e)
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args)
	{
		AddWan adwan = new AddWan();	
		adwan.buildGUI();
	}
}