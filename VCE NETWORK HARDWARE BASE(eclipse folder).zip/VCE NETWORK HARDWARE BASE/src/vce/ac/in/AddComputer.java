package vce.ac.in;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class AddComputer extends Panel 
{
	Button AddComputerButton;
	TextField cidText, mnfText, macText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public AddComputer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB()
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","it18737065","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Button
		AddComputerButton = new Button("Submit");
		AddComputerButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO COMPUTERS (CID,MANUFACTURER,MAC_ADDRESS) VALUES (1,'DELL','00-14-22-01-23-45')";				  
				  String query= "INSERT INTO COMPUTERS VALUES(" + cidText.getText()+", " + "'" + mnfText.getText() + "'," +"'"+ macText.getText() +"')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		cidText = new TextField(15);
		mnfText = new TextField(15);
		macText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("System No.:"));
		first.add(cidText);
		first.add(new Label("Manufacturer:"));
		first.add(mnfText);
		first.add(new Label("MAC ADDRESS:"));
		first.add(macText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(AddComputerButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setVisible(true);
		
		errorText.setBackground(Color.BLACK);
		errorText.setForeground(Color.WHITE);
	}

	private void displaySQLErrors(SQLException e)
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args)
	{
		AddComputer adc = new AddComputer();	
		adc.buildGUI();
	}
}