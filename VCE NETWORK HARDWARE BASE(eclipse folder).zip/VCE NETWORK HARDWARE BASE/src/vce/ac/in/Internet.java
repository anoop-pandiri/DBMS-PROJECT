package vce.ac.in;

public class Internet {

}
